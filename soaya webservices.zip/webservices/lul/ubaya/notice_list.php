<?php
require_once "connection.php";
	header("Content-Type: application/json");
	class User{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
			
			public function GetNoticeList($username)
			{
				$query = "select namefrom,u.profilepic,messages,notdate,type,keyId from notification as n inner join users as u on n.namefrom=u.username where belong=? and namefrom != ? order by notdate desc limit 80";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$username);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}
		
		
		
		}
		
	$user = new User();
	if(!empty($_GET["noticeList"]))
	{
		$username = $_GET["noticeList"];
		$user->GetNoticeList($username);
	}
	
	



?>