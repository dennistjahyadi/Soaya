<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class Relation
	{
		private $db;
		private $connection;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
			}
			
			public function Check($user1,$user2)
			{
				$status;
				$query = "select id from friendrequest where ((user1 = ? and user2=?) or (user1 = ? and user2=?)) and relation='friend'";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ssss",$user1,$user2,$user2,$user1);
			$stmt->execute();
			$stmt->store_result();

				if($stmt->num_rows==1)
				{
					$status='friend'; // status is friend
				}
				else
				{
					$query = "select id from friendrequest where user1 = ? and user2=? and relation='request'";
					$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$user1,$user2);
			$stmt->execute();
			$stmt->store_result();	
					if($stmt->num_rows==1)
					{
						$status='request0'; //waiting for accept	
					}
					else
					{
						$query = "select id from friendrequest where user1 = ? and user2=? and relation='request'";
					
						$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$user2,$user1);
			$stmt->execute();
			$stmt->store_result();		
						if($stmt->num_rows==1)
						{
							$status='request1';// accept friend
						}
						else
						{
							$status='request2';	// add friend
						
						}
					}
				}
				
				$json[$status] = $status;
				echo json_encode($json);	
				$stmt->close();
				$this->connection->close();		
		
			}
			
			
			public function AddFriend($user1,$user2)
			{
				$query = "select id from friendrequest where ((user1 = ? and user2=?) or (user1 = ? and user2=?)) and relation='request'";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ssss",$user1,$user2,$user2,$user1);
				$stmt->execute();
				$stmt->store_result();
				if($stmt->num_rows==0)
				{
					date_default_timezone_set('Asia/Bangkok');
					$datetime = date('Y-m-d H:i:s',time());
					
					$query = "insert into friendrequest (user1,user2,relation,tanggal) values (?,?,'request','$datetime')";
					$stmt= $this->connection->prepare($query);
					$stmt->bind_param("ss",$user1,$user2);
					
					if($stmt->execute())
					{
						$json["success"] = "success";
						echo json_encode($json);	
						
					}
				}
				
				
				
				$stmt->close();
				$this->connection->close();	
			}
			
			public function ConfirmFriend($user1,$user2)
			{
				
				$query = "update friendrequest set relation='friend' where user1=? and user2=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$user2,$user1);
				
				if($stmt->execute())
				{
					$json["success"] = "success";
					echo json_encode($json);	
					
				}
				$stmt->close();
				$this->connection->close();	
			}
		
		
	}
		
		
		
	$relation = new Relation();
	
	if(isset($_POST['user1'],$_POST['user2']))
	{
		$user1 = $_POST["user1"];
		$user2 = $_POST["user2"];
		$relation->Check($user1,$user2);
	}else if(isset($_POST['AddFriendUser1'],$_POST['AddFriendUser2']))
	{
		$user1 = $_POST["AddFriendUser1"];
		$user2 = $_POST["AddFriendUser2"];
		$relation->AddFriend($user1,$user2);
	}else if(isset($_POST['ConfirmUser1'],$_POST['ConfirmUser2']))
	{
		$user1 = $_POST["ConfirmUser1"];
		$user2 = $_POST["ConfirmUser2"];
		$relation->ConfirmFriend($user1,$user2);
	}
			
		
		
	
	

?>