<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowForumList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show($username,$rrr)
			{
				$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where u.username = ? order by f.createDate desc limit 12 offset ?";
				
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$username,$rrr);
			$stmt->execute();
		
				$result = $stmt->get_result();
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();		
					
			}
					
				
		
	}
	
	
	$showForumList = new ShowForumList();
	
	$username = $_GET["username"];

	$rrr = $_GET["poi"];
		
	$showForumList->Show($username,$rrr);		
	
	
		
		
	
	
		
		
	

?>