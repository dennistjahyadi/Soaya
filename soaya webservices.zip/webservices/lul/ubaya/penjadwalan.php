<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
			}
			
			public function does_user_exist($pass)
			{
				
				$stmt= $this->connection->prepare("select * from thepass  where pass = ?");
				$stmt->bind_param("s",$pass);
				$stmt->execute();
				$stmt->store_result();
 
				if($stmt->num_rows>0)
				{
					$json["success"] = "1";
					echo json_encode($json);	
				}
				else
				{
					$json["success"]="0";					
					echo json_encode($json);
				
				}
				
			$stmt->close();
				$this->connection->close();			
			}
			
			
			public function SaveEvent($tanggal,$event,$organisasi,$id)
			{
				
				$stmt= $this->connection->prepare("insert into penjadwalan (tanggal,acara,organisasi,fk_id) values (?,?,?,?)");
				$stmt->bind_param('ssss',$tanggal,$event,$organisasi,$id);
			
				
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);	
				
				}
							
				$stmt->close();
				$this->connection->close();			
			}
			
			public function SaveEvent2($tanggal1,$tanggal2,$event,$organisasi,$user)
			{
				$stmt= $this->connection->prepare("insert into penjadwalanlist (tanggal1,tanggal2,acara,organisasi,user) values (?,?,?,?,?)");
				$stmt->bind_param('sssss',$tanggal1,$tanggal2,$event,$organisasi,$user);
				
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);	
				
				}
							
				$stmt->close();
				$this->connection->close();		
			}
			
			
			public function GetAllEvent()
			{
				$query = "select date(tanggal) as tanggal,acara as event,organisasi from penjadwalan";
				$stmt= $this->connection->prepare($query);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function GetAllEvent2()
			{
				$query = "select id,date(tanggal1) as tanggal1,date(tanggal2) as tanggal2,acara as event,organisasi from penjadwalanlist order by id asc";
				$stmt= $this->connection->prepare($query);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function GetEvent($date)
			{
				$query = "select id,date(tanggal) as tanggal,acara as event,organisasi from penjadwalan where date(tanggal)=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$date);

				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
		
	}
		
		
		
	$user = new User();
	
	
	if(isset($_POST["tanggal"],$_POST["organisasi"],$_POST["event"],$_POST["id"]))
	{
		$tanggal = $_POST["tanggal"];
		$event = $_POST["event"];
		$organisasi = $_POST["organisasi"];
		$id = $_POST["id"];
		$user->SaveEvent($tanggal,$event,$organisasi,$id);
	}else if(isset($_POST["tanggal1"],$_POST["tanggal2"],$_POST["event"],$_POST["organisasi"],$_POST["user"]))
	{
		$tanggal1 =$_POST["tanggal1"];
		$tanggal2 = $_POST["tanggal2"];
		$event = $_POST["event"];
		$organisasi = $_POST["organisasi"];
		$by = $_POST["user"];
		$user->SaveEvent2($tanggal1,$tanggal2,$event,$organisasi,$by);
		
	}
	
	
	
	if(isset($_POST['pass']))
	{
		$pass = $_POST['pass'];
		$user->does_user_exist($pass);
		
	}	
	
	if(!empty($_GET["GetAllEvent"]))
	{
		$user->GetAllEvent();
	}
	if(!empty($_GET["GetAllEvent2"]))
	{
		$user->GetAllEvent2();
	}
	if(!empty($_GET["GetEvent"]))
	{
		$date = $_GET["GetEvent"];
		$user->GetEvent($date);
	}	
	

?>