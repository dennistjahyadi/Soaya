<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
		private $firebaseApi;
		
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}
			
			public function InsertContent($username,$title,$category,$content)
			{
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				$content = $content."\n";
				$stmt= $this->connection->prepare("insert into forum (title,category,createBy,content,createDate,lastPost,views,type) values (?,?,?,?,?,?,'0','normaluser')");
				$stmt->bind_param('ssssss',$title,$category,$username,$content,$datetime,$datetime);
			
			
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);
				$this->send_notification(str_replace(" ","",$category),"from ".$category.", ".$title,"NewThreadNotification",$id,$username);
				
				}
							
				$stmt->close();
				$this->connection->close();			
			
			}
			
	public function InsertContent2($username,$title,$category,$content,$type)
			{
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				$content = $content."\n";
				$stmt= $this->connection->prepare("insert into forum (title,category,createBy,content,createDate,lastPost,views,type) values (?,?,?,?,?,?,'0',?)");
				$stmt->bind_param('sssssss',$title,$category,$username,$content,$datetime,$datetime,$type);
			
			
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);
				$this->send_notification(str_replace(" ","",$category),"[new thread] from ".$category.", ".$title,"NewThreadNotification",$id,$username);
				
				}
							
				$stmt->close();
				$this->connection->close();			
			
			}
				
					
				public function GetImageId($username)
					{
						$stmt= $this->connection->prepare("select id from forumimages where uploadedBy=? order by id desc limit 1");
				$stmt->bind_param("?",$username);
			$stmt->execute();
			$result = $stmt->get_result();
			$result = $result->fetch_assoc();

			
						
						return $result["id"];
					
					}
					
				public function InsertImage($threadId,$url,$caption,$username){
					
					
						$stmt= $this->connection->prepare("insert into forumimages (threadId,url,caption,uploadedBy) values (?,?,?,?)");
				$stmt->bind_param("ssss",$threadId,$url,$caption,$username);
					
					if($stmt->execute())
					{
						$json['success'] = 'Success';
						echo json_encode($json);
						
					}
					$insertedId = $stmt->insert_id;
					$stmt->close();
					$this->connection->close();			
			return $insertedId;
					
				}
				
				public function ClearImage($forumId)
				{
					
					$stmt= $this->connection->prepare("delete from forumimages where threadId=?");
				$stmt->bind_param("s",$forumId);
			$stmt->execute();
					
				
				}

		
			
			
			public function UpdateContent($forumId,$username,$title,$category,$content)
			{
		
				$stmt= $this->connection->prepare("update forum set title=?,content=?,category=? where id=?");
				$stmt->bind_param("ssss",$title,$content,$category,$forumId);
				$stmt->execute();
				if($stmt->execute())
				{
				
				$json['success'] = 'Update Success';
				echo json_encode($json);
				
			
				
				}
					
					$stmt->close();
				$this->connection->close();	
					
				
			}
			
			
			
			
			public function CheckTitle($title)
			{
				
				$stmt= $this->connection->prepare("select * from forum where title=?");
				$stmt->bind_param("s",$title);
				$stmt->execute();
				$stmt->store_result();
				//insert into table forum
				
				

				return $stmt->num_rows;
				
			}
			
			public function CheckTitleForUpdate($threadId,$title)
			{
				
				//insert into table forum
		
				$stmt= $this->connection->prepare("select * from forum where title=? and id != ?");
				$stmt->bind_param("ss",$title,$threadId);
				$stmt->execute();
				$stmt->store_result();

				return $stmt->num_rows;
				
			}
			
			public function getImageUrl($user){
				
				$stmt= $this->connection->prepare("select url from forumimages where uploadedBy=? order by id desc limit 1");
				$stmt->bind_param("s",$user);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				
			
						echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();	
				
			}
			public function GetThreadId($user){
				
				$stmt= $this->connection->prepare("select id from forum where createBy=? order by id desc limit 1");
				$stmt->bind_param("s",$user);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				
			
						echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();	
				
			}
			
			
			public function GetImages($id)
			{
				
				$stmt= $this->connection->prepare("select id,url,caption from forumimages where threadId=?");
				$stmt->bind_param("s",$id);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				
			
						echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();	
			}
			
			public function send_notification($topic, $message,$type,$threadId,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'threadId'=>$threadId,'by'=>$from),
            'to' => '/topics/'.$topic
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
    }
			
			
			public function CloseConnection()
			{
				$this->connection->close();
			}
			
	}
	
	
// ---------------------------------------------------------------------------------------------------------------------
	
		
	$user = new User();
	
	if(isset($_POST['username'],$_POST['title'],$_POST['category'],$_POST['content']))
	{
		$username = $_POST['username'];
		$title = $_POST['title'];
		$category = $_POST['category'];
		$content = $_POST['content'];
	
		$check = $user->CheckTitle($title);

	
				if(!empty($username) && !empty($title)&&!empty($category) &&!empty($content))
				{
					
					if($check>0)
					{
										
						$jsons['error'] = "title already exist";	
						echo json_encode($jsons);
								
					}
					else if($check==0)
					{
						$user -> InsertContent($username,$title,$category,$content);
			
					}
					
					
				}
				else if (empty($title))
				{
					$json['error'] = "please insert the title";	
					echo json_encode($json);
				}
				else if (empty($category))
				{
					$json['error'] = "please insert the category";	
					echo json_encode($json);
				}
				
				else if(empty($content))
				{
					$json['error'] = "please insert the content";
					echo json_encode($json);
				}
			
		
		
	}
	
	if(isset($_POST['username1'],$_POST['title'],$_POST['category'],$_POST['content'],$_POST["type"]))
	{
		$username = $_POST['username1'];
		$title = $_POST['title'];
		$category = $_POST['category'];
		$content = $_POST['content'];
		$type = $_POST["type"];
		$check = $user->CheckTitle($title);

	
				if(!empty($username) && !empty($title)&&!empty($category) &&!empty($content))
				{
					
					if($check>0)
					{
										
						$jsons['error'] = "title already exist";	
						echo json_encode($jsons);
								
					}
					else if($check==0)
					{
						$user -> InsertContent2($username,$title,$category,$content,$type);
			
					}
					
					
				}
				else if (empty($title))
				{
					$json['error'] = "please insert the title";	
					echo json_encode($json);
				}
				else if (empty($category))
				{
					$json['error'] = "please insert the category";	
					echo json_encode($json);
				}
				
				else if(empty($content))
				{
					$json['error'] = "please insert the content";
					echo json_encode($json);
				}
			
		
		
	}
	
	if(isset($_POST['username'],$_POST['threadId'],$_POST['edittitle'],$_POST['editcategory'],$_POST['editcontent']))
	{
		$username = $_POST['username'];
		$forumId = $_POST['threadId'];
		$title = $_POST['edittitle'];
		$category = $_POST['editcategory'];
		$content = $_POST['editcontent'];
	
		$check = $user->CheckTitleForUpdate($forumId,$title);
		
	
				if(!empty($username) && !empty($title)&&!empty($category) &&!empty($content))
				{
					
					if($check>0)
					{
						//$user->ClearImage($forumId);
						$jsons['error'] = "title already exist";	
						echo json_encode($jsons);
								
					}
					else if($check==0)
					{	
						$user->ClearImage($forumId);
						$user -> UpdateContent($forumId,$username,$title,$category,$content); /////////////////////////////
					}
					
					
				}
				else if (empty($title))
				{
					$json['error'] = "please insert the title";	
					echo json_encode($json);
				}
				else if (empty($category))
				{
					$json['error'] = "please insert the category";	
					echo json_encode($json);
				}
				
				else if(empty($content))
				{
					$json['error'] = "please insert the content";
					echo json_encode($json);
				}
			
		
		
	}
	
	
	if(isset($_POST['username'],$_POST['threadId'],$_POST['encoded'],$_POST['caption']))
	{
		$username = $_POST['username'];
		$threadId = $_POST['threadId'];
		$encoded_string = $_POST['encoded'];
		$caption = $_POST['caption'];
	
	
			$url = 'http://103.31.251.226/lul/ubaya/forumimages/';
			$imageId=$user ->InsertImage($threadId,$url,$caption,$username);	

			//$imageId = $user->GetImageId($username);
			
			$decoded_string = base64_decode($encoded_string);
			
			
			$path = 'forumimages/pic_'.$imageId.'.jpg';
			
			$file = fopen($path, 'wb');
			
			$is_written = fwrite($file,$decoded_string);
			
			fclose($file);
			
			
			if($is_written > 0)
			{	
				$user->CloseConnection();			
			}	
		
			
	}
	
	
	
	
	if(!empty($_GET["threadId"]))
	{
		$username = $_GET["threadId"];
		$user->GetThreadId($username);	
			
	}
	if(!empty($_GET["GetImagesForUpdate"]))
	{
		$threadId = $_GET["GetImagesForUpdate"];
		$user->GetImages($threadId);
	}
	
	
	/*if(isset($_POST["SendNotification"]))
	{
		$user->send_notification("FakultasTeknik","test","NewThreadNotification","50","tonton");
	}*/

?>