<?php 

	require_once "connection.php";
	header("Content-Type: application/json");
class User
	{
		private $db;
		private $connection;
		private $firebaseApi;
		
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}

			public function aaa($category,$title,$threadId)
			{
				$this->send_notification($category,$title,"NewThreadNotification",$threadId,"adminnnn");
	
			}

public function send_notification($topic, $message,$type,$threadId,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'threadId'=>$threadId,'by'=>$from),
            'to' => '/topics/'.$topic
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }else
		{
			$json["success"] = "1";
			echo json_encode($json);	
		}

        // Close connection
        curl_close($ch);
        echo $result;
    }
	}
	
	$user = new User();
	if(isset($_POST['category'],$_POST['title'],$_POST['threadId']))
	{
		$category = $_POST['category'];
		$title = $_POST['title'];
		$id = $_POST['threadId'];
		$user->aaa(str_replace(" ","",$category),$title,$id);
		
	}	
	
	
	
?>