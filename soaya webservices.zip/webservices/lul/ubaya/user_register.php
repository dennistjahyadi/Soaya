<?php
	
	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
		
		function __construct()
		{
			$this->db= new DB_Connection();
			$this->connection = $this->db->get_connection();
		}
		
		public function InsertIntoSubs($username,$subscategory)
		{
			$subscategory = str_replace(" ","",$subscategory);
			$query = "insert into subscribe(username,subscategory) values (?,?)";
			
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$subscategory);
			$stmt->execute();
			
			$query = "insert into subscribe(username,subscategory) values (?,'SeputarUbaya')";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$username);
			
			
			if($stmt->execute())
			{
				$json['success']='Account created '.$username;
			}	
			
			echo json_encode($json);
			$stmt->close();
			$this->connection->close();	
			
		}
		
		public function does_user_exist($name,$username,$email,$fakultas)
		{
			
			if (!preg_match("/^[a-zA-Z ]*$/",$name)) 
			{
				$json['error']= "Full Name hanya boleh menggunakan spasi dan huruf";
				echo json_encode($json);
				$this->connection->close();	
			}
			else if(!preg_match("/^[a-zA-Z0-9]*$/",$username))
			{
				$json['error']="username tidak boleh mengandung special character dan spasi";	
				echo json_encode($json);
				$this->connection->close();	
			}
			
			else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
			{
				$json['error'] = "format email salah";
				echo json_encode($json);
				$this->connection->close();	
			}
			
			else
			{
				
				$stmt= $this->connection->prepare("select username from users where username=?");
				$stmt->bind_param("s",$username);
				$stmt->execute();
				$stmt->store_result();
				
				$checkUserName2 = $stmt->num_rows;
				
				$checkEmail = "select email from users where email=?";
				$stmt= $this->connection->prepare($checkEmail);
				$stmt->bind_param("s",$email);
				$stmt->execute();
				$stmt->store_result();
				
				$checkEmail2 = $stmt->num_rows;
				
				if($checkUserName2>0)
				{
					$json['error']="Username sudah tersedia";	
					echo json_encode($json);
					$stmt->close();
					$this->connection->close();	
				}else if($checkEmail2>0)
				{
					$json['error']="email sudah digunakan";	
					echo json_encode($json);
					$stmt->close();
					$this->connection->close();	
					
				}else
				{
					
					$query = "insert into users(name,username,fakultas,email) values (?,?,?,?)";
					
					$stmt= $this->connection->prepare($query);
					$stmt->bind_param("ssss",$name,$username,$fakultas,$email);
					
					
					if($stmt->execute())
					{
						$this->InsertIntoSubs($username,$fakultas);
					}	
					
					$stmt->close();
					
				}
				
			}
			
		}
		
	}
	
	
	
	$user = new User();
	
	if(isset($_POST['name'],$_POST['username'],$_POST['fakultas'],$_POST['email']))
	{
		$email = $_POST['email'];
		$name = $_POST['name'];
		$username = $_POST['username'];
		
		$fakultas = $_POST['fakultas'];
		
		if(!empty($email)&&!empty($username)&&!empty($name)&&!empty($fakultas))
		{
			
			$user -> does_user_exist($name,strtolower($username),strtolower($email),$fakultas);
			
		}
		else
		{
			$json['error']='you must fill all fields';
			echo json_encode($json);
			
		}
		
		}	
		
		
		?>		