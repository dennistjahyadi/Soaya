<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
		private $firebaseApi;
		
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}
			
			public function SaveEvent($tanggal,$event,$category,$color)
			{
				
				$stmt= $this->connection->prepare("insert into calendarubaya (tanggal,event,category,color) values (?,?,?,?)");
				$stmt->bind_param('ssss',$tanggal,$event,$category,$color);
			
				
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);	
				
				}
							
				$stmt->close();
				$this->connection->close();			
			}
			
			public function SaveEvent2($tanggal1,$tanggal2,$event,$category,$color)
			{
				$stmt= $this->connection->prepare("insert into calendarubayalist (tanggal1,tanggal2,event,category,color) values (?,?,?,?,?)");
				$stmt->bind_param('sssss',$tanggal1,$tanggal2,$event,$category,$color);
				
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);	
				
				}
							
				$stmt->close();
				$this->connection->close();		
			}
			
			
			public function GetAllEvent()
			{
				$query = "select tanggal,event,category,color from calendarubaya";
				$stmt= $this->connection->prepare($query);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function GetAllEvent2()
			{
				$query = "select id,tanggal1,tanggal2,event,category,color from calendarubayalist order by id asc";
				$stmt= $this->connection->prepare($query);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function GetEvent($date)
			{
				$query = "select id,tanggal,event from calendarubaya where tanggal=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$date);

				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			

			
			
	}
	
	
// ---------------------------------------------------------------------------------------------------------------------
	
		
	$user = new User();
	
	if(isset($_POST["tanggal"],$_POST["event"],$_POST["category"],$_POST["color"]))
	{
		$tanggal = $_POST["tanggal"];
		$event = $_POST["event"];
		$category = $_POST["category"];
		$color = $_POST["color"];
		$user->SaveEvent($tanggal,$event,$category,$color);
	}else if(isset($_POST["tanggal1"],$_POST["tanggal2"],$_POST["event"],$_POST["category"],$_POST["color"]))
	{
		$tanggal1 =$_POST["tanggal1"];
		$tanggal2 = $_POST["tanggal2"];
		$event = $_POST["event"];
		$category = $_POST["category"];
		$color = $_POST["color"];
		$user->SaveEvent2($tanggal1,$tanggal2,$event,$category,$color);
		
	}
	
	if(!empty($_GET["GetAllEvent"]))
	{
		$user->GetAllEvent();
	}
	if(!empty($_GET["GetAllEvent2"]))
	{
		$user->GetAllEvent2();
	}
	if(!empty($_GET["GetEvent"]))
	{
		$date = $_GET["GetEvent"];
		$user->GetEvent($date);
	}	

?>