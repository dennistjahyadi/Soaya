<?php
header ('Content-type : bitmap; charset=utf-8');
require_once "connection.php";


	class Pictures
	{
		
		private $db;
		private $connection;
		function __construct()
		{
			$this->db= new DB_Connection();
			$this->connection = $this->db->get_connection();
		}
		
		public function UpdatePic($username,$path)
		{
			$query = "update users set profilepic=? where username=?";
			
			$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$path,$username);

			if($stmt->execute())
			{
				$json['success'] = 'Success';
				echo json_encode($json);
			}
			
			$stmt->close();
				$this->connection->close();		

		}
		
		public function GetUserId($email)
		{
			$query = "select id from users where email=?";
			
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$email);
			$stmt->execute();
			
			$result = $stmt->get_result();
			$result->fetch_assoc();
			return $query2["id"];
			
		}
		
		public function SavePic($username)
		{
			
			$query = "insert into profileimages (username) values (?)";
			
			$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$username);

			$stmt->execute();
			
			$id = $stmt->insert_id;
			$stmt->close();
			return $id;

		}
		
		
	}





$PicturesClass = new Pictures();
		

if(isset($_POST["encoded_string"]))
{
	if(!empty($_POST["encoded_string"]) || !empty($_POST["username"]))
	{
		
		$encoded_string = $_POST["encoded_string"];
		$username = $_POST["username"];
		
		$decoded_string = base64_decode($encoded_string);
		$picId = $PicturesClass->SavePic($username);
		
		
		$path = 'profileimages/'.$picId.'.jpg';
		
		$file = fopen($path, 'wb');
		
		$is_written = fwrite($file,$decoded_string);
		fclose($file);
		
		if($is_written > 0)
		{
			$path2 = "http://103.31.251.226/lul/ubaya/profileimages/".$picId.".jpg";
			$PicturesClass = new Pictures();
			$PicturesClass->UpdatePic($username,$path2);
				
		}	
	
	}
		
}


?>