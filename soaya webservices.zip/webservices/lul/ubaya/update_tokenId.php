<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
			}
			
			public function update_token($username,$token)
			{
				$stmt=$this->connection->prepare("update users set fcmID=? where username = ?");
				$stmt->bind_param('ss', $token,$username);
				
				
				if($stmt->execute())
				{
					$json["success"]="";
					echo json_encode($json);

				}	
					
$stmt->close();
$this->connection->close();			
				
			}
		
	}
		
		
		
	$user = new User();
	
	if(isset($_POST['username'],$_POST['token']))
	{
		$username = $_POST['username'];
		$token = $_POST['token'];
		
		if(!empty($username)&&!empty($token))
		{
			
			$user -> update_token($username,$token);
			
		}
		
		
	}	
	

?>