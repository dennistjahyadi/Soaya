<?php

require_once "connection.php";
	header("Content-Type: application/json");
	class GCM {
    //put your code here
    // constructor
	private $db;
		private $connection;
						private $firebaseApi;

    function __construct() {
        $this->db= new DB_Connection();
		$this->connection = $this->db->get_connection();
		$this->firebaseApi = $this->db->get_firebase_api();

    }
    /**
     * Sending Push Notification
     */
    public function send_notification($registatoin_ids, $message,$type,$threadId,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'threadId'=>$threadId,'by'=>$from),
            'to' => $registatoin_ids
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
    }
	
	public function GetTokenId($username)
	{
		$query = "select fcmID from users where username=?";
		$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$username);
			$stmt->execute();
			$result=$stmt->get_result();
			$result =$result->fetch_assoc();
			$stmt->close();

		return $result["fcmID"];
		
	}
	
	public function SaveNoticeToDb($from,$usernameJsonArrayTo,$messages,$threadId,$createBy)
	{
		date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
		for($i=0;$i<count($usernameJsonArrayTo);$i++)
		{
			$to =$usernameJsonArrayTo[$i];

			if($to!=$createBy)
			{
			$query = "insert into notification (belong,namefrom,messages,notdate,type,keyId) values (?,?,?,?,'commentnotice',?)";
			
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sssss",$to,$from,$messages,$datetime,$threadId);
			$stmt->execute();
			
			}
			
			usleep(100000);
		}
		
	
		
		$stmt->close();
	}
	
	public function SaveNoticeToDb2($from,$to,$messages,$threadId)
	{
		date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
			
			$query = "insert into notification (belong,namefrom,messages,notdate,type,keyId) values (?,?,?,?,'someonecommentyourthread',?)";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sssss",$to,$from,$messages,$datetime,$threadId);
			
				
		if($stmt->execute())
		{
			$json["success"]="";	
		}
		$stmt->close();

	}
	public function SaveNoticeToDb3($from,$to,$threadId)
	{
			date_default_timezone_set('Asia/Bangkok');
			$datetime = date('Y-m-d H:i:s',time());
			$messages = "[new thread] from ".$this->GetThreadCategory($threadId)."\n ".$this->GetThreadTitle($threadId);
			$query = "insert into notification (belong,namefrom,messages,notdate,type,keyId) values (?,?,?,?,'newthread',?)";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sssss",$to,$from,$messages,$datetime,$threadId);
			
				
		if($stmt->execute())
		{
			$json["success"]="";	
		}
		$stmt->close();

	}
	public function GetThreadTitle($threadId)
	{
	
			$query = "select title from forum where id=?";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$threadId);
			$stmt->execute();
			$result=$stmt->get_result();
			$result =$result->fetch_assoc();
			$stmt->close();

		return $result["title"];
	}
	public function GetThreadCategory($threadId)
	{
	
			$query = "select category from forum where id=?";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$threadId);
			$stmt->execute();
			$result=$stmt->get_result();
			$result =$result->fetch_assoc();
			$stmt->close();

		return $result["category"];
	}

}

$gcm = new GCM();

//mention notification
	if(isset($_POST["from"],$_POST["jsonArrayUsername"],$_POST["messages"],$_POST["createBy"],$_POST["threadId"]))
	{
		$type="ThreadNotification";
		$threadId = $_POST["threadId"];
		$messages=$_POST["messages"];
		$createBy = $_POST["createBy"];
		$from = $_POST["from"];
		//get token id
		$usernameArrayTo = $_POST["jsonArrayUsername"];
		$usernameJsonArrayTo = json_decode($usernameArrayTo);
		$gcm->SaveNoticeToDb($from,$usernameJsonArrayTo,$messages,$threadId,$createBy);
		if(count($usernameJsonArrayTo)>0)
		{
			for( $i=0;$i<count($usernameJsonArrayTo);$i++)
			{
				if($usernameJsonArrayTo[$i]!=$from)
				{
				$tokenId = $gcm->GetTokenId($usernameJsonArrayTo[$i]);
				$tokenArray[]= $tokenId;
				usleep(80000);
				}
			}
		}
		
		$jsonArrayToken =  json_decode(json_encode($tokenArray));
		
//------------------------------------------------------------------------------
		$totalToken = count($jsonArrayToken);
		
		for($a=0;$a<$totalToken;$a++)
		{
			$token = $jsonArrayToken[$a];
			$gcm->send_notification($token,$from." mention you in comment",$type,$threadId,$from);
			usleep(100000);
		}
						
	}else if(isset($_POST["from"],$_POST["to"],$_POST["messages"],$_POST["threadId"]))
	{
		$type="ThreadNotification";
		$threadId = $_POST["threadId"];
		$from = $_POST["from"];
		$to = $_POST["to"];
		$messages=$_POST["messages"];
		$gcm->SaveNoticeToDb2($from,$to,$messages,$threadId);
		
		$tokenId = $gcm->GetTokenId($to);
		$gcm->send_notification($tokenId,$from." comment your thread",$type,$threadId,$from);
	}else if(isset($_POST["from"],$_POST["to"],$_POST["newThread"]))
	{
		$from = $_POST["from"];
		$to = $_POST["to"];
		$threadId = $_POST["newThread"];
		$gcm->SaveNoticeToDb3($from,$to,$threadId);

	}else if(isset($_POST["aassdd"]))
	{
		$username =$_POST["aassdd"];
		$token = $gcm->GetTokenId($username);
		$gcm->send_notification($token,"asdf","ThreadNotification","2","tonton");	
	}


?>