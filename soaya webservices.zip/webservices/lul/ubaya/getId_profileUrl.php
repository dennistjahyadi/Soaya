<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
			}
			
			public function does_user_exist($email)
			{
				
				$stmt= $this->connection->prepare("select id,username from users where email = ?");
				$stmt->bind_param("s",$email);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				
			
						echo json_encode($rows);
						$stmt->close();
				$this->connection->close();	
				
		
			}
			public function GetPicUrl($email)
			{
				
				$stmt= $this->connection->prepare("select profilepic from users where email = ?");
				$stmt->bind_param("s",$email);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}

						echo json_encode($rows);
						$stmt->close();
				$this->connection->close();	
		
			}
			
			public function GetSubs($username)
			{
				
				$stmt= $this->connection->prepare("select subscategory from subscribe where username = ?");
				$stmt->bind_param("s",$username);
			$stmt->execute();
			
			$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				
			
						echo json_encode($rows);
						$stmt->close();
				$this->connection->close();	
		
			}
		
	}
		
		
		
	$user = new User();
	
	if(!empty($_GET["poi"]))
	{
	$email = $_GET["poi"];
	$user -> does_user_exist($email);
	}else if (!empty($_GET["userPic"]))
	{
		$email = $_GET["userPic"];
		$user -> GetPicUrl($email);
	}else if (!empty($_GET["getSubs"]))
	{
		$username = $_GET["getSubs"];
		$user -> GetSubs($username);
	}
			
		
		
	
	

?>