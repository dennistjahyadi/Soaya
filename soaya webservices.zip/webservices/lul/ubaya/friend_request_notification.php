<?php

require_once "connection.php";
	header("Content-Type: application/json");
	class GCM {
    //put your code here
    // constructor
	private $db;
		private $connection;
				private $firebaseApi;

    function __construct() {
        $this->db= new DB_Connection();
		$this->connection = $this->db->get_connection();
		$this->firebaseApi = $this->db->get_firebase_api();

    }
    /**
     * Sending Push Notification
     */
    public function send_notification($registatoin_ids, $message,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>'FriendRequestNotification','by'=>$from),
            'to' => $registatoin_ids
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
    }
	
	public function GetTokenId($username)
	{
		$query = "select fcmID from users where username=?";
		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$result = $stmt->get_result();
		$result =$result->fetch_assoc();
		return $result["fcmID"];
		$stmt->close();
	}
	

}

$gcm = new GCM();

	if(isset($_POST["notifFriendRequestTo"],$_POST["notifFriendRequestFrom"]))
	{
		$usernameTo = $_POST["notifFriendRequestTo"];
		$usernameFrom = $_POST["notifFriendRequestFrom"];
		
		$token = $gcm->GetTokenId($usernameTo);
		
		$gcm->send_notification($token,"Friend Request from ".$usernameFrom,$usernameFrom);
	}


?>