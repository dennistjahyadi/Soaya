<?php
define('hostname', 'localhost');
define('username','root');
define('password','');
define('db_name','smile');

define('GOOGLE_API_KEY','AIzaSyDY_PPB2j8Rj8Pk6jzv1WqAQ2TaAYfRpzg');

//AIzaSyDY_PPB2j8Rj8Pk6jzv1WqAQ2TaAYfRpzg
?>