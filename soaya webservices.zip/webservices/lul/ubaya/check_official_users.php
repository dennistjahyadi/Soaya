<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class OfficialUsers
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show()
			{		
			
					$query = "select username from officialusers";
	
					$stmt= $this->connection->prepare($query);
					$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
					
		
		
	}
	
	
	$officialUsers = new officialUsers();
	
	$officialUsers->Show();
	
	
		
		
	

?>