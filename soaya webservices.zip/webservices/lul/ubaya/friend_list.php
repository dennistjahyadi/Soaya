<?php
require_once "connection.php";
	header("Content-Type: application/json");
	class User{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
			
			public function GetFriendList($username,$rrr)
			{
				$query = "select fr.user1,fr.user2,u1.profilepic as profilepic1,u2.profilepic as profilepic2,u1.id as id1,u2.id as id2,u1.name as name1,u2.name as name2 from friendrequest as fr inner join users as u1 on fr.user1=u1.username inner join users as u2 on fr.user2=u2.username where (fr.user1=? or fr.user2=?) and fr.relation='friend' limit 15 offset ?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sss",$username,$username,$rrr);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}
				
				public function GetFriendList1($username)
			{
				$query = "select fr.user1,fr.user2,u1.profilepic as profilepic1,u2.profilepic as profilepic2,u1.id as id1,u2.id as id2,u1.name as name1,u2.name as name2 from friendrequest as fr inner join users as u1 on fr.user1=u1.username inner join users as u2 on fr.user2=u2.username where (fr.user1=? or fr.user2=?) and fr.relation='friend'";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$username);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}
		
		
		}
		
	$user = new User();
	if(!empty($_GET["friendList"]))
	{
		$username = $_GET["friendList"];
		$rrr = $_GET["rrr"];
		$user->GetFriendList($username,$rrr);
	}
	if(!empty($_GET["friendList1"]))
	{
		$username = $_GET["friendList1"];
		
		$user->GetFriendList1($username);
	}

?>