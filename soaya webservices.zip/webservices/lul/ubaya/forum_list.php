<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowForumList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show($rrr,$sortBy)
			{
				$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.type != 'official' order by f.createDate desc limit 12 offset ?";
				if($sortBy=="newest")
				{
				$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.type != 'official' order by f.createDate desc limit 12 offset ?";
				}else if($sortBy=="mostPopular")
				{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username left join forumcomment as fc on f.id=fc.forumId where f.type != 'official' group by fc.forumId order by totalReply desc limit 12 offset ?";
				}else if($sortBy=="lastPost")
				{
						$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.type != 'official' order by f.lastPost desc limit 12 offset ?";
				}else if($sortBy=="mostViewed")
				{
						$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.type != 'official' order by f.views desc limit 12 offset ?";
				}
				
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$rrr);
				$stmt->execute();
			
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();							
			}
					
				
		
	}
	
	
	$showForumList = new ShowForumList();
	
	
	if(!empty($_GET["sortBy"])){
		
	$rrr = $_GET["poi"];
	$sort = $_GET["sortBy"];
		
	$showForumList->Show($rrr,$sort);
		
		}
		
	
	
		
		
	
	
		
		
	

?>