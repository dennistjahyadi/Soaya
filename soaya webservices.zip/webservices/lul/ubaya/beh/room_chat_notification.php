<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class RoomChat
	{
		private $db;
		private $connection;
		private $firebaseApi;
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}
			
			public function CreateChatRoom($createBy,$jsonArray)
			{
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				
				$query = "select id,users from chatroom where users=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$jsonArray);
			$stmt->execute();
			$stmt->store_result();
			$totalrow = $stmt->num_rows;
				
				if($totalrow>0)  //check if room is exist
				{
					$query = "select id,users from chatroom where users=?";
					$stmt= $this->connection->prepare($query);
					$stmt->bind_param("s",$jsonArray);
					$stmt->execute();
			 		$result=$stmt->get_result();

					$getid = $result->fetch_assoc();
					$getid = $getid["id"];
					$json["success"]=$getid;
					echo json_encode($json);
				}else
				{
				
									$query = "insert into chatroom (createBy,lastMessage,users) values (?,?,?)";
									$stmt= $this->connection->prepare($query);
									$stmt->bind_param("sss",$createBy,$datetime,$jsonArray);
									
									
					
									if($stmt->execute())
									{
										
										$id = $stmt->insert_id;;
										$json["success"]=$id;
										echo json_encode($json);
										/*$jsonArray = json_decode($jsonArray);
										for($i=0;$i<count($jsonArray);$i++)
										{
											$user = $jsonArray[$i];
											
												$token=$this->GetTokenId($user);
												usleep(10000);
												$this->SendNotification($token,"roominvitation",$createBy." invite you to room chat",$id,"null",$createBy);
												usleep(25000);
					
										
										}*/
										
										
									}
									
				}
					$stmt->close();
				$this->connection->close();	
				
			}
			
			public function GetRoomId($createBy)
			{
				
				$query = "select id from chatroom where createBy=? order by id desc limit 1";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$createBy);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	

		
			}
			
			public function GetRoomUsers($roomid)
			{
			
				$query = "select users,roomname from chatroom where id=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$roomid);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	

			}
			public function GetTokenId($username)
			{
				$query = "select fcmID from users where username=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$username);
			$stmt->execute();
			$result=$stmt->get_result();
				$result=$result->fetch_assoc();
				
				$stmt->close();
				return $result["fcmID"];
				
			
				
			}
			public function SendMessage($roomid,$messages,$type,$sender,$users)
			{
				
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				
				$query = "insert into chattext (roomid,messages,type,thedate,sender) values (?,?,?,?,?)";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sssss",$roomid,$messages,$type,$datetime,$sender);
			$stmt->execute();
			
				$idMessages =$stmt->insert_id;

				$updateRoom = "update chatroom set lastMessage=? where id=?";
				$stmt= $this->connection->prepare($updateRoom);
				$stmt->bind_param("ss",$datetime,$roomid);
				
					
				if($type=="picture")
				{
					$messages="send a picture";
				}else if($type=="thread")
				{
					$messages="share a thread";
				}
				
				if($stmt->execute())
				{
					
					$json["success"]=$idMessages;
					echo json_encode($json);

					for( $i=0;$i<count($users);$i++)
						{
							if($users[$i]!=$sender)
							{
							
							$tokenId = $this->GetTokenId($users[$i]);
							usleep(25000);

							$this->SendNotification($tokenId,"messagesNotification",$sender.": ".$messages,$roomid,$idMessages,$sender);

							usleep(25000);
							}
						}
			

				}
				else
				{
					$json["0"]="";
					echo json_encode($json);

				}

					$stmt->close();
				$this->connection->close();

			}
			
			
			public function GetThread($id)
			{
				$query = "select f.title,SubString(f.content,1,70) as content,u.username as createBy,u.profilepic from forum as f inner join users as u on f.createBy=u.username where f.id=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$id);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
				echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();
					
			}
			
			
			public function GetMessageList($roomid,$rrr)
			{
				$query = "select ct.id,ct.messages,ct.type,DATE_FORMAT(ct.thedate,'%h:%i %p') as thetime,ct.thedate as thedate,ct.sender,u.profilepic from chattext as ct inner join users as u on ct.sender=u.username where ct.roomid=? order by id desc limit 15 offset ?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$roomid,$rrr);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
				echo json_encode($rows);
					
					$stmt->close();
				$this->connection->close();
			}
			
			public function GetSingleMessage($id)
			{
				
				$query = "select ct.id,ct.messages,ct.type,DATE_FORMAT(ct.thedate,'%h:%i %p') as thetime,ct.thedate as thedate,ct.sender,u.profilepic from chattext as ct inner join users as u on ct.sender=u.username where ct.id=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$id);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
				
			}
			
			public function InviteUserToRoom($invitedUsers,$roomid,$by,$usersinRoom,$allusers)
			{
				
				
				$query = "select id,users from chatroom where users=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$allusers);
			$stmt->execute();
			$result = $stmt->get_result();
			$stmt->store_result();
				
			
				
				if($stmt->num_rows==1)// if there is a room, the app will redirect to existed room
				{
					$getid = $result->fetch_assoc();
					$getid = $getid["id"];
					$json["success2"]=$getid;
					echo json_encode($json);
				}
				else
				{
					date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
						$query = "update chatroom set lastMessage=?,users=? where id=?";
						$stmt= $this->connection->prepare($query);
						$stmt->bind_param("sss",$datetime,$allusers,$roomid);
						$stmt->execute();
						
						$json["success"]="";
						echo json_encode($json);
						
						for($i=0;$i<count($invitedUsers);$i++)
						{
							$users = $invitedUsers[$i];
							$tokenId = $this->GetTokenId($users);
							usleep(50000);
		
							$messages = $users." join the chat";
							
							$query = "insert into chattext (roomid,messages,type,thedate,sender) values (?,?,'roominfo',?,?)";
		
							$stmt= $this->connection->prepare($query);
						$stmt->bind_param("ssss",$roomid,$messages,$datetime,$by);
						$stmt->execute();
							$idMessages = $stmt->insert_id;
							
							for($a=0;$a<count($usersinRoom);$a++)
							{
								
								$roomusers = $usersinRoom[$a];
								$tokens = $this->GetTokenId($roomusers);
								$this->SendNotification($tokens,"messagesNotification",$users." join your room chat",$roomid,$idMessages,$by);
								usleep(25000);
								
							}
								
							if($result==1)
							{
								$this->SendNotification($tokenId,"messagesNotification",$by." invite you to room chat",$roomid,$idMessages,$by);
								usleep(25000);
		
							}
							
							usleep(80000);
						}
				}
				
			}
			
			
			public function SaveImageAndGetTheId($roomid,$url,$uploadedBy)
			{
				$query = "insert into chatimages (roomid,url,uploadedBy) values (?,?,?)";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("sss",$roomid,$url,$uploadedBy);
			
				
				if($stmt->execute())
				{
					
					$id = $stmt->insert_id;
					return $id;	

				}
				
			}
			
			
			public function SendNotification($to,$type,$message,$roomid,$idMessages,$from)
			{
				   $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'roomid'=>$roomid,'id'=>$idMessages,'by'=>$from),
            'to' => $to
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
				
			}
			
			
			public function GetFriendList($username)
			{
			$query = "select fr.user1,fr.user2,u1.profilepic as profilepic1,u2.profilepic as profilepic2,u1.id as id1,u2.id as id2,u1.name as name1,u2.name as name2 from friendrequest as fr inner join users as u1 on fr.user1=u1.username inner join users as u2 on fr.user2=u2.username where (fr.user1=? or fr.user2=?) and fr.relation='friend'";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$username);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
			}
			
			public function GetRoomUsers2($roomid)
			{
			
				$query = "select users from chatroom where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$roomid);
				$stmt->execute();	
				$result = $stmt->get_result();
				$result= $result->fetch_assoc();
				return $result["users"];
			}
			public function GetTotalChat($roomid)
			{
			
				$query = "select count(*) as jumlah from chattext where roomid=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$roomid);
				$stmt->execute();	
				$result = $stmt->get_result();
				while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
			}
	
	
	public function ChangeRoomName($roomname,$roomid,$by,$usersinRoom)
			{
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				
				$query = "update chatroom set lastMessage=?,roomname=? where id=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("sss",$datetime,$roomname,$roomid);
			
				if($stmt->execute())
				{
						
						$json["success"]="";
						echo json_encode($json);
						
						
							$messages = $by." change the room name into ".$roomname;
							$query = "insert into chattext (roomid,messages,type,thedate,sender) values (?,?,'roominfo',?,?)";
		
							$stmt= $this->connection->prepare($query);
							$stmt->bind_param("ssss",$roomid,$messages,$datetime,$by);
							$stmt->execute();
							$idMessages = $stmt->insert_id;
						
						for($i=0;$i<count($usersinRoom);$i++)
						{
							$users = $usersinRoom[$i];
													
							$tokenId = $this->GetTokenId($users);
							usleep(25000);

							$this->SendNotification($tokenId,"messagesNotification",$messages,$roomid,$idMessages,$by);

							usleep(25000);
							
							
						}
				}
				
				mysqli_close($this->connection);
			
				
			}
	
	
	
			
	}
		
		
	$roomchat = new RoomChat();
	
	if(isset($_POST["createRoom"],$_POST["createBy"],$_POST["usersArray"]))
	{
		$createBy = $_POST["createBy"];
		$jsonArray = $_POST["usersArray"];
		$roomchat->CreateChatRoom($createBy,$jsonArray);
	
	}
	
	if(isset($_POST["room"],$_POST["messages"],$_POST["type"],$_POST["sender"]))
	{
		$roomid = $_POST["room"];
		$messages= $_POST["messages"];
		$type= $_POST["type"];
		$sender= $_POST["sender"];
		$users = $roomchat->GetRoomUsers2($roomid);
		$users = json_decode($users);
		
		$roomchat->SendMessage($roomid,$messages,$type,$sender,$users);
	
	}
	
	if(isset($_POST["encoded_string"],$_POST["uploadBy"],$_POST["roomid"]))
	{
		if(!empty($_POST["encoded_string"]))
		{		
			$encoded_string = $_POST["encoded_string"];
			$uploadedBy = $_POST["uploadBy"];
			$roomid = $_POST["roomid"];
			$users = $roomchat->GetRoomUsers2($roomid);
			$users = json_decode($users);
			$url = "http://103.31.251.226/lul/ubaya/chatimages/";
			$imageid = $roomchat->SaveImageAndGetTheId($roomid,$url,$uploadedBy);

			$decoded_string = base64_decode($encoded_string);
			
			$path = 'chatimages/'.$imageid.'.jpg';
			
			$file = fopen($path, 'wb');
			
			$is_written = fwrite($file,$decoded_string);
			fclose($file);
			
			if($is_written > 0)
			{
				$url = "http://103.31.251.226/lul/ubaya/chatimages/".$imageid.".jpg";
				$roomchat->SendMessage($roomid,$url,"picture",$uploadedBy,$users);
			}	
		
		}
		
	}
	
		if(isset($_POST["inviteUsers"],$_POST["roomid"],$_POST["by"],$_POST["usersinRoom"],$_POST["allusers"]))
	{
		$invitedUsers = $_POST["inviteUsers"];
		$roomId = $_POST["roomid"];
		$by = $_POST["by"];
		$usersinRoom=$_POST["usersinRoom"];
		$allusers = $_POST["allusers"];
		$invitedUsers = json_decode($invitedUsers);
		$usersinRoom =json_decode($usersinRoom);
		$roomchat->InviteUserToRoom($invitedUsers,$roomId,$by,$usersinRoom,$allusers);
	
	}
	
	if(isset($_POST["changeRoomName"],$_POST["roomid"],$_POST["by"]))
	{
		$roomname = $_POST["changeRoomName"];
		$roomid = $_POST["roomid"];
		$by = $_POST["by"];
		$usersinRoom = $roomchat->GetRoomUsers2($roomid);
		$usersinRoom =json_decode($usersinRoom);
		$roomchat->ChangeRoomName($roomname,$roomid,$by,$usersinRoom);



	}
	
	if(!empty($_GET["getThread"]))
	{
		$threadId = $_GET["getThread"];

		$roomchat->GetThread($threadId);
	}
	
	
	
	if(!empty($_GET["getMessageList"]))
	{
		$roomid = $_GET["getMessageList"];
		$rrr = $_GET["rrr"];
		$roomchat->GetMessageList($roomid,$rrr);
	}
	
	if(!empty($_GET["idMessages"]))
	{
		$id = $_GET["idMessages"];
		
		$roomchat->GetSingleMessage($id);
	}
	
	if(!empty($_GET["getRoomId"]))
	{
		$username = $_GET["getRoomId"];
		$roomchat->GetRoomId($username);
	}
	if(!empty($_GET["getRoomUsers"]))
	{
		$roomid = $_GET["getRoomUsers"];
		$roomchat->GetRoomUsers($roomid);
	}
	if(!empty($_GET["getFriendList"]))
	{
		$username = $_GET["getFriendList"];
		$roomchat->GetFriendList($username);
	}
	if(!empty($_GET["getTotalChat"]))
	{
		$roomid = $_GET["getTotalChat"];
		$roomchat->GetTotalChat($roomid);
	}
	
	
	
			
		
		
	
	

?>