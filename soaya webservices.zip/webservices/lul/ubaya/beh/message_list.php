<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class Message
	{
		private $db;
		private $connection;
		private $firebaseApi;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();

			}
			
			
			
			public function GetMessageList($username)
			{
				$username = "%".$username."%";
				$stmt = $this->connection->prepare("select cr.id,cr.users,cr.lastMessage,cr.roomname,ct.messages,ct.type,ct.sender from chatroom as cr left join 
(select tmp.roomid,tmp.type,tmp.messages,tmp.sender,tmp.thedate FROM
(select roomid,type,messages,sender,thedate from chattext order by thedate desc) as tmp group by tmp.roomid)
as ct on cr.id=ct.roomid where cr.users like ? group by cr.users order by cr.lastMessage,ct.thedate desc");
				$stmt->bind_param("s", $username);
				$stmt->execute();
				$result = $stmt->get_result();
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
		
					
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();			
				}
			
			public function GetMessageSingleList($id)
			{
				$stmt = $this->connection->prepare("select cr.id,cr.users,cr.lastMessage,cr.roomname,ct.messages,ct.type,ct.sender from chatroom as cr left join 
(select tmp.roomid,tmp.type,tmp.messages,tmp.sender,tmp.thedate FROM
(select roomid,type,messages,sender,thedate from chattext order by thedate desc) as tmp group by tmp.roomid)
as ct on cr.id=ct.roomid where cr.id= ? group by cr.users order by cr.lastMessage,ct.thedate desc");
				$stmt->bind_param('s', $id);
				$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();			}
			public function GetUser($username)
			{
				$stmt = $this->connection->prepare("select id,name,profilepic from users where username=?");
				$stmt->bind_param('s', $username);
				$stmt->execute();
				$result = $stmt->get_result();
				while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
		
				echo json_encode($rows);

				$stmt->close();
				$this->connection->close();
			}
		public function GetTotalRoom($username)
			{
				$username ="%".$username."%";
			
				$stmt = $this->connection->prepare("select count(*) as jumlah from chatroom where users like ?");
				$stmt->bind_param('s', $username);
				$stmt->execute();
				$result = $stmt->get_result();
				while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
			
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
		
			}
				public function GetRoomName($roomid)
			{
				
				$stmt = $this->connection->prepare("select roomname from chatroom where id=?");
				$stmt->bind_param('s', $roomid);
				$stmt->execute();
				$result = $stmt->get_result();
				while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
		
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();

			
			}
				public function UpdateRoomUsers($roomid,$roomusers,$by)
			{
				
				$stmt = $this->connection->prepare("update chatroom set users=? where id=?");
				$stmt->bind_param('ss',$roomusers,$roomid);
				
				
				if($stmt->execute())
				{					
					$json["success"]="";
					echo json_encode($json);
					date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
					$messages = $by." left the chat";
							
							$query = "insert into chattext (roomid,messages,type,thedate,sender) values (?,?,'roominfo',?,?)";
		
							$stmt= $this->connection->prepare($query);
						$stmt->bind_param("ssss",$roomid,$messages,$datetime,$by);
						$stmt->execute();
							$idMessages = $stmt->insert_id;
							$roomusers = json_decode($roomusers);
							for($a=0;$a<count($roomusers);$a++)
							{
								
								$user = $roomusers[$a];
								$tokens = $this->GetTokenId($user);
								$this->SendNotification($tokens,"messagesNotification",$by." left the chat",$roomid,$idMessages,$by);
								usleep(25000);
								
							}
							

				}
		
				$stmt->close();
				$this->connection->close();

			
			}
			
			public function GetTokenId($username)
			{
				$query = "select fcmID from users where username=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$username);
			$stmt->execute();
			$result=$stmt->get_result();
				$result=$result->fetch_assoc();
				
				$stmt->close();
				return $result["fcmID"];
				
			
				
			}
			
			
				public function SendNotification($to,$type,$message,$roomid,$idMessages,$from)
			{
				   $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'roomid'=>$roomid,'id'=>$idMessages,'by'=>$from),
            'to' => $to
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
				
			}
			
			
	}
		
		
		
	$message = new Message();
	
	if(!empty($_GET["messageList"]))
	{
		$username = $_GET["messageList"];
		
		$message->GetMessageList($username);
	}
	
	
	if(!empty($_GET["messageSingleList"]))
	{
		$id = $_GET["messageSingleList"];
		
		$message->GetMessageSingleList($id);
	}
	if(!empty($_GET["getTheUsers"]))
	{
		$username = $_GET["getTheUsers"];
		$message->GetUser($username);
	}
	if(!empty($_GET["checkTotalRoom"]))
	{
		$username = $_GET["checkTotalRoom"];
		$message->GetTotalRoom($username);
	}
	if(!empty($_GET["getRoomName"]))
	{
		$roomid = $_GET["getRoomName"];
		$message->GetRoomName($roomid);
	}
	if(isset($_POST["roomid"],$_POST["roomusers"],$_POST["by"]))
	{
		$roomid = $_POST["roomid"];
		$roomusers = $_POST["roomusers"];
		$by = $_POST["by"];
		$message->UpdateRoomUsers($roomid,$roomusers,$by);
		
	
	}

	
	
			
		
		
	
	

?>