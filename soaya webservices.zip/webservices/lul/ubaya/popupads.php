<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class PopUpAds
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Jumlah()
			{		
			
					$query = "select count(*) as jumlah from popupads";
	
					$stmt= $this->connection->prepare($query);
					$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
			
			public function Show()
			{		
			
					$query = "select url from popupads";
	
					$stmt= $this->connection->prepare($query);
					$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
					
		
		
	}
	
	
	$pop = new PopUpAds();
	
	if(!empty($_GET["jumlah"]))
	{
	$pop->Jumlah();
	}
	if(!empty($_GET["geturl"]))
	{
	$pop->Show();
	}
	
		
		
	

?>