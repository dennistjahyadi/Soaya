<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class PostList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show($forumId)
			{
					$query = "select f.id,f.title,f.content, f.category,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where f.id=?";
					$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$forumId);
			$stmt->execute();
			
			
				$result = $stmt->get_result();
				
				
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						

				$stmt->close();
				$this->connection->close();		

			}
			
			public function GetImages($id)
			{
				$query="select id,url,caption from forumimages where threadId=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$id);
				$stmt->execute();	
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				
				$stmt->close();
				$this->connection->close();		
				
				
			}
				
			public function GetComments($id,$offset)
			{
				$query="select u.username as postBy,date(fc.postDate) as theDate,time(fc.postDate) as theTime,fc.text,u.profilepic from forumcomment as fc inner join users as u on fc.postBy=u.username where fc.forumId=? order by fc.id desc limit 15 offset ?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$id,$offset);
				$stmt->execute();	
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
			}	
			
			
			public function SendComments($username,$threadId,$comment)
			{
			
				date_default_timezone_set('Asia/Bangkok');
				$datetime = date('Y-m-d H:i:s',time());
				
				$query = "insert into forumcomment (forumId,text,postBy,postDate) values (?,?,?,?);";
				$query1 = "update forum set lastPost=? where id=?;";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ssss",$threadId,$comment,$username,$datetime);
				$result=$stmt->execute();

				$stmt1= $this->connection->prepare($query1);
				$stmt1->bind_param("ss",$datetime,$threadId);
				$result1=$stmt1->execute();
			
				if($result == 1 && $result1==1 )
				{
					$json['success'] = 'success';
					echo json_encode($json);	
					
				}
				$stmt->close();
				$this->connection->close();
			}
			
			public function GetTotalComment($id)
			{
				$query = "select count(forumId) as jumlah from forumcomment where forumId=? group by forumId ";
			$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$id);
			$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
			
			public function GetTotalImages($id)
			{
				$query = "select count(threadId) as jumlah from forumimages where threadId=? group by threadId ";
			$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$id);
			$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
			
			public function IncreaseView($threadId)
			{
				
				$query = "select views from forum where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$threadId);
				$stmt->execute();
				$result = $stmt->get_result();
				$result=$result->fetch_assoc();
				$num = $result["views"];
				$num +=1;
				$stmt->close();
				
				$query = "update forum set views=? where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$num,$threadId);
				$stmt->execute();
				
				
			
				$stmt->close();
				$this->connection->close();
			}
				
		
	}
	
	$showForumList = new PostList();
	
	if(!empty($_GET["poi"]))
	{
	$id = $_GET["poi"];
	$showForumList->Show($id);			
	}else if(!empty($_GET["getimages"]))
	{
		$id = $_GET["getimages"];
		$showForumList->GetImages($id);
	}
	else if(!empty($_GET["getcomments"]))
	{
		$id=$_GET["getcomments"];
		$offset = $_GET["offset"];
		$showForumList->GetComments($id,$offset);
	}else if(!empty($_GET["totalcomments"]))
	{
		$id=$_GET["totalcomments"];
		$showForumList->GetTotalComment($id);
	}else if(!empty($_GET["totalimages"]))
	{
		$id=$_GET["totalimages"];
		$showForumList->GetTotalImages($id);
	
	}
	
	if(isset($_POST["username"],$_POST["threadId"],$_POST["comment"]))
	{
		$username = $_POST["username"];
		$threadId = $_POST["threadId"];
		$comment = $_POST["comment"];
		
		$showForumList->SendComments($username,$threadId,$comment);
			
	
	}
		
	if(isset($_POST["increaseViews"]))
	{
		$threadId = $_POST["increaseViews"];
		
		$showForumList->IncreaseView($threadId);			
	
	}

?>