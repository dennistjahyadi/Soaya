<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowWartaList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function GetAllWarta()
			{		
					
					$query = "select id,title,version,totalpage,location from wartaubaya order by version desc";
					
				$stmt= $this->connection->prepare($query);
				$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
					
			}
			
		
					
		
	}
	
	
	$showWarta = new ShowWartaList();
	
	if(!empty($_GET["getAllWarta"]))
	{
		
		$showWarta->GetAllWarta();
		
	}
		
	
	
		
		
	

?>