<?php
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
require_once "connection.php";
	header("Content-Type: application/json");
	class Category{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
			
			
			
				
					public function GetCategory()
			{
				$query = "select * from category";
				$stmt= $this->connection->prepare($query);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}	
			
			public function GetJustCategory($type)
			{
				$query = "select * from category where type=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$type);

			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}
			
		
				
		public function GetSubCategoryById($categoryid)
			{
				$query = "select * from category where categoryid=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$categoryid);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();	
				
			}
		
		
		}
		
	$category = new Category();
	if(!empty($_GET["GetCategory"]))
	{
		$category->GetCategory();
	}
	if(!empty($_GET["GetJustCategory"]))
	{
		$type = $_GET["GetJustCategory"];
		$category->GetJustCategory($type);
	}
	
	if(!empty($_GET["GetSubCategoryById"]))
	{
		$categoryid = $_GET["GetSubCategoryById"];
		$category->GetSubCategoryById($categoryid);
	}
?>