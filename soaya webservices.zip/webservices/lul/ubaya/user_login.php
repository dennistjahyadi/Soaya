<?php

	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
	
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
			}
			
			public function does_user_exist($email)
			{
				
				$stmt= $this->connection->prepare("select * from users where email = ?");
				$stmt->bind_param("s",$email);
				$stmt->execute();
				$stmt->store_result();
 
				if($stmt->num_rows==1)
				{
					$json["success"] = "1";
					echo json_encode($json);	
				}
				else
				{
					$json["success"]="0";					
					echo json_encode($json);
				
				}
				
			$stmt->close();
				$this->connection->close();			
			}
		
	}
		
		
		
	$user = new User();
	
	if(isset($_POST['email']))
	{
		$email = $_POST['email'];
		$user->does_user_exist($email);
		
	}	
	

?>