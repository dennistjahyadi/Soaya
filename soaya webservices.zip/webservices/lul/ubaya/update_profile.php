<?php
header ('Content-type : bitmap; charset=utf-8');
require_once "connection.php";


	class Profile
	{
		
		private $db;
		private $connection;
		function __construct()
		{
			$this->db= new DB_Connection();
			$this->connection = $this->db->get_connection();
		}
		
		public function UpdateProfile($name,$username,$email)
		{
			$query = "update users set name=?,email=? where username=?";
			
			$stmt= $this->connection->prepare($query);
				$stmt->bind_param("sss",$name,$email,$username);

			if($stmt->execute())
			{
				$json['success'] = 'Success';
				echo json_encode($json);
			}
			
			$stmt->close();
				$this->connection->close();		

		}
		
		
		public function ChangePassword($username,$currentpassword,$newpassword)
		{
			$query = "select username from users where username=? and password=?";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$currentpassword);
			$stmt->execute();
			$stmt->store_result();
			$totalrow = $stmt->num_rows;
			if($totalrow==1)
			{
				$query = "update users set password=? where username=? and password=?";		
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("sss",$newpassword,$username,$currentpassword);
				if($stmt->execute())
					{
						$json['success'] = 'Success';
						echo json_encode($json);
					}
			
						
			}else
			{
				$json["error"]="current password is wrong";
				echo json_encode($json);
						
			}
			
			$stmt->close();
				$this->connection->close();	
		}
	
	}





$profile = new Profile();
		
if(isset($_POST["username"],$_POST["name"],$_POST["email"]))
{
	$username = $_POST["username"];
	$name = $_POST["name"];
	$email = $_POST["email"];
	
	if (!preg_match("/^[a-zA-Z ]*$/",$name)) 
		{
			 $json['error']= "Name hanya boleh menggunakan spasi dan huruf";
			 echo json_encode($json);
			$this->connection->close();	
			}else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
			{
			 $json['error'] = "format email salah";
				 echo json_encode($json);
			$this->connection->close();	
			}else
				{
	$profile->UpdateProfile($name,$username,$email);
			}
}

if(isset($_POST["username"],$_POST["currentpassword"],$_POST["newpassword"]))
{
	$username = $_POST["username"];
	$currentpassword = md5($_POST["currentpassword"]);
	$newpassword = md5($_POST["newpassword"]);
	
	$profile->ChangePassword($username,$currentpassword,$newpassword);



}

?>