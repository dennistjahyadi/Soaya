<?php
header("Content-Type: application/json");
require_once "connection.php";


class Subscribe
{

	private $db;
	private $connection;
	function __construct()
	{
		$this->db= new DB_Connection();
		$this->connection = $this->db->get_connection();
	}

	public function InsertIntoTable($username,$subscategory)
	{
		$query = "select * from subscribe where username=? and subscategory=?";

		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("ss",$username,$subscategory);
		$stmt->execute();
		$stmt->store_result();
		if($stmt->num_rows>0)
		{
			$stmt->close();
			$this->connection->close();	
		}
		else
		{
			$query = "insert into subscribe (username,subscategory) values (?,?)";

			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$subscategory);

			if($stmt->execute())
			{
				$json['success'] = 'Success';
				echo json_encode($json);
			}

			$stmt->close();
			$this->connection->close();		
		}
	}


	public function RemoveFromTable($username,$subscategory)
	{
		$query = "delete from subscribe where username=? and subscategory=?";

		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("ss",$username,$subscategory);

		if($stmt->execute())
		{
			$json['success'] = 'Success';
			echo json_encode($json);
		}

		$stmt->close();
		$this->connection->close();		

	}

	public function GetSubscribe($username)
	{
		$query = "select c.id,s.username,s.subscategory,c.picurl,c.name from subscribe as s inner join category as c on s.subscategory=c.subsname where s.username = ?";

		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$result = $stmt->get_result();

		while($row=$result->fetch_assoc())
		{
			$rows[] = $row;

		}
		echo json_encode($rows);
		$stmt->close();
		$this->connection->close();		

	}

	public function GetTotalSubscribe($username)
	{
		$query = "select count(*) as jumlah from subscribe as s inner join category as c on s.subscategory=c.subsname where s.username = ?";

		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$result = $stmt->get_result();

		while($row=$result->fetch_assoc())
		{
			$rows[] = $row;

		}
		echo json_encode($rows);
		$stmt->close();
		$this->connection->close();		

	}


}



$subscribe = new Subscribe();


if(isset($_POST["username"],$_POST["subscategory"]))
{
	$username = $_POST["username"];
	$subscategory  = $_POST["subscategory"];
	$subscribe->InsertIntoTable($username,$subscategory);
}
if(isset($_POST["username"],$_POST["removesubscategory"]))
{
	$username = $_POST["username"];
	$subscategory  = $_POST["removesubscategory"];
	$subscribe->RemoveFromTable($username,$subscategory);
}
if(!empty($_GET["getSubscribe"]))
{
	$username = $_GET["getSubscribe"];
	$subscribe->GetSubscribe($username);
}
if(!empty($_GET["totalSubscribe"]))
{
	$username = $_GET["totalSubscribe"];
	$subscribe->GetTotalSubscribe($username);
}

?>