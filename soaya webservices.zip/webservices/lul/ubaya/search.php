<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowForumList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function ShowForum($text,$rrr)
			{		
					$text = "%".$text."%";
					
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,date(f.createDate) as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.title like ? limit 15 offset ?";
					
					$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$text,$rrr);
			$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
					
			}
			
			public function ShowPeople($username,$rrr)
			{		
					$username="%".$username."%";
					
					$query = "select id,name,username,profilepic from users where username like ? or name like '%$username%' limit 15 offset ?";
					
					$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$username,$rrr);
			$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
					
					
					
			}
					
		
	}
	
	
	$showForumList = new ShowForumList();
	
	if(!empty($_GET["searchForum"]))
	{
		
		$search = $_GET["searchForum"];
		$rrr = $_GET["rrr"];
		$showForumList->ShowForum($search,$rrr);
		
	}else if(!empty($_GET["searchPeople"]))
	{
		
	
		$search = $_GET["searchPeople"];
		$rrr = $_GET["rrr"];
		$showForumList->ShowPeople($search,$rrr);
	}
		
	
	
		
		
	

?>