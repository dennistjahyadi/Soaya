<?php
require_once "connection.php";
	header("Content-Type: application/json");
	class User{
		private $db;
		private $connection;
		private $firebaseApi;

			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}
			
			public function GetFriendList($username,$rrr)
			{
				$query = "select fr.id as friendRequestId,u.id as userId, u.name,u.username,u.profilepic from friendrequest as fr inner join users as u on fr.user1=u.username where fr.user2=? and fr.relation='request' limit 15 offset ?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$rrr);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();		
				
			}
			
			public function DeleteFriendRequest($id)
			{
			$query = "delete from friendrequest where id=?";
				$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$id);
			
				if($stmt->execute())
				{
					$json['success'] = 'success';
					echo json_encode($json);
					
				}
			$stmt->close();
				$this->connection->close();	
			}
					
					
			public function AcceptFriendRequest($id)
			{
			$query = "update friendrequest set relation='friend' where id=?";
			$stmt= $this->connection->prepare($query);
			$stmt->bind_param("s",$id);
			
				if($stmt->execute())
				{
					$json['success'] = 'success';
					echo json_encode($json);
					$query = "select user1,user2 from friendrequest where id=?";
					$stmt= $this->connection->prepare($query);
					$stmt->bind_param("s",$id);
					$stmt->execute();
					$result = $stmt->get_result();
					$result =$result->fetch_assoc();
					$user1 = $result["user1"];
					$user2 = $result["user2"];
					$token=$this->GetTokenId($user1);
					echo $token;
					$this->send_notification($token,$user2." accept your friend request",$user2);

				}
			$stmt->close();
			$this->connection->close();	
			
			}
			
			 public function send_notification($registatoin_ids, $message,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>'FriendRequestNotification','by'=>$from),
            'to' => $registatoin_ids
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
    }
	
	public function GetTokenId($username)
	{
		$query = "select fcmID from users where username=?";
		$stmt= $this->connection->prepare($query);
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$result = $stmt->get_result();
		$result =$result->fetch_assoc();
		return $result["fcmID"];
		$stmt->close();
	}
			
		
		
		}
		
	$user = new User();
	if(!empty($_GET["friendRequest"]))
	{
		$username = $_GET["friendRequest"];
		$rrr = $_GET["rrr"];
		$user->GetFriendList($username,$rrr);
	}
	
	if(isset($_POST["deleteFriendRequest"]))
	{
		$friendrequestid = $_POST["deleteFriendRequest"];
		$user->DeleteFriendRequest($friendrequestid);
	}else if(isset($_POST["acceptFriendRequest"]))
	{
		$friendrequestid = $_POST["acceptFriendRequest"];
		$user->AcceptFriendRequest($friendrequestid);

	}


?>