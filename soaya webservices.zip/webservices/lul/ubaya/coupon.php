<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	require_once "connection.php";
	header("Content-Type: application/json");
	class User
	{
		private $db;
		private $connection;
		private $firebaseApi;
		
			function __construct()
			{
				$this->db= new DB_Connection();
				$this->connection = $this->db->get_connection();
				$this->firebaseApi = $this->db->get_firebase_api();
			}
			
			public function SaveCoupon($title,$startDate,$expDate,$picUrl,$description,$username)
			{
				
				$description = $description."\n";
				$stmt= $this->connection->prepare("insert into couponlist (title,startDate,expDate,photoUrl,description) values (?,?,?,?,?)");
				$stmt->bind_param('sssss',$title,$startDate,$expDate,$picUrl,$description);
			
			
				if($stmt->execute())
				{
				$id = $stmt->insert_id;
				$json['success'] = $id;
				echo json_encode($json);	
				$this->send_notification("Coupon","[new coupon] ".$title,"CouponNotification",$id,$username);
				
				}
							
				$stmt->close();
				$this->connection->close();			
			}
			
			public function GetAllCoupon($rrr)
			{
				$query = "select id,title,expDate,photoUrl from couponlist order by id desc limit 15 offset ?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$rrr);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function GetTheCoupon($id)
			{
				$query = "select title,startDate,expDate,photoUrl,description from couponlist where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$id);
				$stmt->execute();
			
				$result = $stmt->get_result();

					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
						echo json_encode($rows);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function CheckExpiredCoupon($id)
			{
				date_default_timezone_set('Asia/Bangkok');
				$now = date('Y-m-d H:i:s',time());
				
				$query = "select title,startDate,expDate,photoUrl,description from couponlist where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$id);
				$stmt->execute();
			
				$result = $stmt->get_result();
				$row=$result->fetch_assoc();
				$startDate = $row["startDate"];
				$expDate = $row["expDate"];
				
				$dateNow=new DateTime($now);
				$dateStart=new DateTime($startDate);
				$dateExpired = new DateTime($expDate);
					
				if($dateExpired >= $dateNow && $dateStart <=$dateNow){
				 // do ur stuff
				 $json["success"]="allowed";
				}else
				{
				 $json["error"]="Expired";
				
				}
				
				echo json_encode($json);
				
				
				
						
				$stmt->close();
				$this->connection->close();			
			}
			
			public function CheckExpiredCoupon2($id)
			{
				date_default_timezone_set('Asia/Bangkok');
				$now = date('Y-m-d H:i:s',time());
				
				$query = "select title,startDate,expDate,photoUrl,description from couponlist where id=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('s',$id);
				$stmt->execute();
			
				$result = $stmt->get_result();
				$row=$result->fetch_assoc();
				$startDate = $row["startDate"];
				$expDate = $row["expDate"];
				
				$dateNow=new DateTime($now);
				$dateStart=new DateTime($startDate);
				$dateExpired = new DateTime($expDate);
					
				if($dateExpired >= $dateNow && $dateStart <=$dateNow){
					
				 $json=1; //allowed
				 
				}else
				{
					
				 $json =0; //expired
				
				}
				
				$stmt->close();
				return $json;
			}
			
			public function UseCoupon($couponId,$username)
			{
				$stmt= $this->connection->prepare("insert into usercoupon (couponId,username) values (?,?)");
				$stmt->bind_param('ss',$couponId,$username);
				
				if($this->CheckExpiredCoupon2($couponId)==1)
				{
					if($stmt->execute())
						{
						$json['success'] = "success";
						}
				}else
				{
					$json["error"] = "maaf kupon ini sudah kadaluarsa";
				}
				
						
				echo json_encode($json);				

				$stmt->close();
				$this->connection->close();	
			}
			
			public function CheckSudahDigunakan($couponid,$username)
			{
				$query = "select count(*) as jumlah from usercoupon where couponId=? and username=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param('ss',$couponid,$username);
				$stmt->execute();
			
				$result = $stmt->get_result();
				$row=$result->fetch_assoc();
				
				$json["success"]=$row["jumlah"];
				
				echo json_encode($json);
						
				$stmt->close();
				$this->connection->close();				
			}
			
			public function send_notification($topic, $message,$type,$threadId,$from) {
        // include config

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

       $fields = array(
			'data' => array('text' => $message,'type'=>$type,'couponId'=>$threadId,'by'=>$from),
            'to' => '/topics/'.$topic
        );

        $headers = array(
            'Authorization: key='.$this->firebaseApi,
            'Content-Type: application/json',
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        echo $result;
    }
			
			
	}
	
	
// ---------------------------------------------------------------------------------------------------------------------
	
		
	$user = new User();
	
	
	if(isset($_POST['title'],$_POST['startDate'],$_POST['expDate'],$_POST['encodedImage'],$_POST['description'],$_POST["username"]))
	{
		$title=$_POST['title'];
		$startDate=$_POST['startDate'];
		$expDate=$_POST['expDate'];
		$encodedImage=$_POST['encodedImage'];
		$description=$_POST['description'];
		$username = $_POST["username"];
		date_default_timezone_set('Asia/Bangkok');
		$date = new DateTime();
		$picname= $date->getTimestamp();
		if(!empty($title) && !empty($startDate)&&!empty($expDate) &&!empty($encodedImage)&&!empty($description))
		{
			$decoded_string = base64_decode($encodedImage);
		$path = 'couponimages/'.$picname.'.jpg';
		
		$file = fopen($path, 'wb');
		
		$is_written = fwrite($file,$decoded_string);
		fclose($file);
		
			if($is_written > 0)
			{
				$picUrl = "http://103.31.251.226/lul/ubaya/couponimages/".$picname.".jpg";
				$user->SaveCoupon($title,$startDate,$expDate,$picUrl,$description,$username);
					
			}	
		}
		else
		{
			$json["error"]="semua form harus diisi";
			echo json_encode($json);
		}

	}
	
	if(isset($_POST["id"]))
	{
		$id = $_POST["id"];
		$user->CheckExpiredCoupon($id);
	}
	
	if(isset($_POST["UseCoupon"],$_POST["username"]))
	{
		$couponId = $_POST["UseCoupon"];
		$username = $_POST["username"];
		$user->UseCoupon($couponId,$username);
	}
	if(isset($_POST["CheckSudahDigunakan"],$_POST["username"]))
	{
		$couponId = $_POST["CheckSudahDigunakan"];
		$username = $_POST["username"];
		$user->CheckSudahDigunakan($couponId,$username);
	}
	
	if(!empty($_GET["GetAllCoupon"]))
	{
		$rrr = $_GET["rrr"];
		$user->GetAllCoupon($rrr);
	}else if(!empty($_GET["GetTheCoupon"]))
	{
		$id = $_GET["GetTheCoupon"];
		$user->GetTheCoupon($id);
	}

	

?>