<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowForumList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show($asd,$rrr,$sortBy)
			{		
				if($sortBy=="newest")
				{
					$order = "order by f.createDate desc";
					
				}else if($sortBy=="mostPopular")
				{
					$order ="order by totalReply desc";

				}else if($sortBy=="lastPost")
				{
					$order = "order by f.lastPost desc";
					
				}else if($sortBy=="mostViewed")
				{
					$order = "order by f.views desc";
				}
			
			
					if($asd=="FakultasTeknik")
					{	
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.category = 'Sistem Informasi' or f.category='Multimedia' or f.category like 'Teknik%' or f.category = 'Fakultas Teknik' and f.type != 'official' ".$order." limit 12 offset $rrr";
					}
					else if($asd == "FakultasHukum")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.category = 'Jurusan Hukum Internasional' or f.category like 'Hukum%' or f.category = 'Fakultas Hukum' and f.type != 'official' ".$order." limit 12 offset $rrr";
					}else if($asd == "FakultasBisnisdanEkonomika")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.category = 'Perbankan dan Investasi' or f.category = 'Bisnis Internasional' or f.category = 'Keuangan Korporat' or f.category = 'Pasar Modal' or f.category = 'Marketing' or f.category = 'Manajemen Layanan dan Pariwisata' or f.category = 'Manajemen Jejaring Bisnis' or f.category = 'Manajemen SDM dan Organisasi' or f.category = 'Akuntansi' or f.category = 'IBN' or f.category = 'Professional Accounting' or f.category = 'Fakultas Bisnis dan Ekonomika' and f.type != 'official' ".$order." limit 12 offset $rrr";
					}else if($asd == "FakultasIndustriKreatif")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where f.category = 'DMP' or f.category like 'DFP' or f.category = 'Fakultas Industri Kreatif' and f.type != 'official' ".$order." limit 12 offset $rrr";
					}
					else
					{
						$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic,(select count(*) from forumcomment where forumId=f.id group by forumId) as totalReply,f.views,(select concat(url,'pic_',id,'.jpg') from forumimages where threadId=f.id group by threadId limit 1) as imageUrl from forum as f inner join users as u on f.createBy=u.username where replace(f.category, ' ', '') = '$asd' and f.type != 'official' ".$order." limit 12 offset $rrr";
					}
			
	
					$stmt= $this->connection->prepare($query);
					$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}
					
				public function ShowSearch($asd,$rrr,$text,$sortBy)
			{		
			
			if($sortBy=="newest")
				{
					$order = "order by f.createDate desc";
					
				}else if($sortBy=="mostPopular")
				{
					$order ="order by totalReply desc";

				}else if($sortBy=="lastPost")
				{
					$order = "order by f.lastPost desc";
					
				}else if($sortBy=="mostViewed")
				{
					$order = "order by f.views desc";
				}
			
			
			
					if($asd=="FakultasTeknik")
					{	
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where (f.category = 'Sistem Informasi' or f.category='Multimedia' or f.category like 'Teknik%' or f.category = 'Fakultas Teknik') and f.title like ?  ".$order." limit 15 offset $rrr";
					}
					else if($asd == "FakultasHukum")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where (f.category = 'Jurusan Hukum Internasional' or f.category like 'Hukum%' or f.category = 'Fakultas Hukum') and f.title like ? ".$order." limit 15 offset $rrr";
					}else if($asd == "FakultasBisnisdanEkonomika")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where (f.category = 'Perbankan dan Investasi' or f.category = 'Bisnis Internasional' or f.category = 'Keuangan Korporat' or f.category = 'Pasar Modal' or f.category = 'Marketing' or f.category = 'Manajemen Layanan dan Pariwisata' or f.category = 'Manajemen Jejaring Bisnis' or f.category = 'Manajemen SDM dan Organisasi' or f.category = 'Akuntansi' or f.category = 'IBN' or f.category = 'Professional Accounting' or f.category = 'Fakultas Bisnis dan Ekonomika') and f.title like ? ".$order." limit 15 offset $rrr";
					}else if($asd == "FakultasIndustriKreatif")
					{
					$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where (f.category = 'DMP' or f.category like 'DFP' or f.category = 'Fakultas Industri Kreatif') and f.title like ? ".$order." limit 15 offset $rrr";
					}
					else
					{
						$query = "select f.id,f.title,f.category,SubString(f.content,1,70) as content,u.username as createBy,f.createDate as theDate,u.profilepic from forum as f inner join users as u on f.createBy=u.username where (replace(f.category, ' ', '') = '$asd') and f.title like ? ".$order." limit 15 offset $rrr";
					}
			
					$text = "%".$text."%";
					$stmt= $this->connection->prepare($query);
					$stmt->bind_param("s",$text);
					$stmt->execute();
				$result = $stmt->get_result();
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
				echo json_encode($rows);
				$stmt->close();
				$this->connection->close();
			}	
		
	}
	
	
	$showForumList = new ShowForumList();
	
	if(!empty($_GET["search"]))
	{
		$search = $_GET["search"];
		$asd = $_GET["poi"];
		$rrr = $_GET["rrr"];
		$sortBy = $_GET["sortBy"];
		$showForumList->ShowSearch($asd,$rrr,$search,$sortBy);			
	}else
	{
		$asd = $_GET["poi"];
		$rrr = $_GET["rrr"];
		$sortBy = $_GET["sortBy"];
		$showForumList->Show($asd,$rrr,$sortBy);
	
	}
	
	
	
		
		
	

?>