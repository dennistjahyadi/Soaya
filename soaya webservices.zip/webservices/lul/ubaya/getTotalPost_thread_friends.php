<?php
require_once "connection.php";
	header("Content-Type: application/json");
	class User{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
			
			public function GetTotalPost($username)
			{
				$query = "select count(*) as jumlah from forumcomment where postBy=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$username);
				$stmt->execute();
				$result = $stmt->get_result();
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();		
				
			}
				
			public function GetTotalThread($username)
			{
				$query = "select count(*) as jumlah from forum where createBy=?";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("s",$username);
				$stmt->execute();
				$result = $stmt->get_result();
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();		
			}
			
			public function GetTotalFriend($username)
			{
			$query = "select count(*) as jumlah from friendrequest where (user1=? or user2=?) and relation='friend'";
				$stmt= $this->connection->prepare($query);
				$stmt->bind_param("ss",$username,$username);
				$stmt->execute();
				$result = $stmt->get_result();
				
					while($row=$result->fetch_assoc())
					{
							$rows[] = $row;

					}
					echo json_encode($rows);
				$stmt->close();
				$this->connection->close();		
			}
		
		}
		
	$user = new User();
	if(!empty($_GET["totalPost"]))
	{
		$username = $_GET["totalPost"];
		$user->GetTotalPost($username);
	
	}else if(!empty($_GET["totalThread"]))
	{
		$username = $_GET["totalThread"];
		$user->GetTotalThread($username);
	}else if(!empty($_GET["totalFriend"]))
	{
		$username = $_GET["totalFriend"];
		$user->GetTotalFriend($username);
	}


?>