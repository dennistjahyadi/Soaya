<?php
	require_once "connection.php";
	header("Content-Type: application/json");

	class ShowCommentList
	{
		private $db;
		private $connection;
		
			function __construct()
			{
				$this->db = new DB_Connection();
				$this->connection = $this->db->get_connection();
				
			}
				
			public function Show($username,$rrr)
			{
				$query = "select f.id as threadId,fc.postDate as theDate, f.title,fc.text
from forumcomment as fc inner join forum as f on fc.forumId=f.id where fc.postBy = ? order by postDate DESC limit 15 offset ?";
				
				
					
					$stmt= $this->connection->prepare($query);
			$stmt->bind_param("ss",$username,$rrr);
			$stmt->execute();
			$result = $stmt->get_result();
			while($row=$result->fetch_assoc())
				{
					$rows[] = $row;

				}
						echo json_encode($rows);
						
					$stmt->close();
				$this->connection->close();		
					
			}
					
				
		
	}
	
	
	$showCommentList = new ShowCommentList();
	
	$username = $_GET["username"];

	$rrr = $_GET["poi"];
		
	$showCommentList->Show($username,$rrr);		
	
	
		
		
	
	
		
		
	

?>